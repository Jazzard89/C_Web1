﻿namespace MvcGroentenEnFruit2023.Data.DefaultData
{
    public static class Roles 
    {
        public const string Aankoper = "Aankoper"; 
        public const string Gast = "Gast"; 
    }
}
