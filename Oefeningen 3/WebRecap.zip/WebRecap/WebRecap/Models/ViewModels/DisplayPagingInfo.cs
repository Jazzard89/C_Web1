﻿namespace WebRecap.Models.ViewModels
{
    public class DisplayPagingInfo
    {
        public PagingInfo PagingInfo { get; set; }
        public bool? Top { get; set; } = true;
    }
}
